import os
import re
from PIL import Image

def resize_and_replace_icons(source_image_path, target_directory):
    """
    Đọc ảnh gốc, quét các file trong thư mục đích, lấy kích thước từ tên file
    và ghi đè bằng ảnh đã resize.
    """
    # Mở ảnh gốc
    try:
        source_img = Image.open(source_image_path)
    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy ảnh gốc tại '{source_image_path}'")
        return
    except Exception as e:
        print(f"Lỗi khi mở ảnh gốc: {e}")
        return

    # Biểu thức chính quy (Regex) để tìm các file có tên dạng android-chrome-WxH.png
    # và trích xuất W (width) cũng như H (height)
    pattern = re.compile(r'^mstile-(\d+)x(\d+)\.png$')
    
    # Đếm số lượng file đã xử lý
    processed_count = 0

    # Lặp qua tất cả các file trong thư mục đích
    for filename in os.listdir(target_directory):
        match = pattern.match(filename)
        if match:
            width = int(match.group(1))
            height = int(match.group(2))
            target_path = os.path.join(target_directory, filename)

            try:
                # Resize ảnh gốc theo kích thước lấy được từ tên file
                # Sử dụng LANCZOS để đảm bảo chất lượng ảnh tốt nhất khi thu phóng
                resized_img = source_img.resize((width, height), Image.Resampling.LANCZOS)
                
                # Lưu đè lên file cũ
                resized_img.save(target_path, format="PNG")
                print(f"Đã ghi đè thành công: {filename} (Kích thước: {width}x{height})")
                processed_count += 1
                
            except Exception as e:
                print(f"Lỗi khi xử lý file {filename}: {e}")

    print(f"\nHoàn tất! Đã xử lý và ghi đè {processed_count} ảnh.")

if __name__ == "__main__":
    # --- CẤU HÌNH ĐƯỜNG DẪN TẠI ĐÂY ---
    
    # Đường dẫn tới ảnh gốc 500x500 của bạn
    SOURCE_IMAGE = r"C:\Users\AGOJ\Documents\New folder\ChatGPT_Image_09_25_15_4_thg_6__2026-removebg-preview.png" 
    
    # Đường dẫn tới thư mục chứa các file android-chrome-...png cần thay thế
    TARGET_DIR = r"C:\Users\AGOJ\Documents\New folder\icons" 
    
    resize_and_replace_icons(SOURCE_IMAGE, TARGET_DIR)