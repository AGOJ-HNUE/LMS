import logging
import re
from operator import itemgetter
from urllib.parse import quote

from django import forms
from django.contrib.auth import password_validation
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from requests import HTTPError
from reversion import revisions
from social_core.backends.github import GithubOAuth2
from social_core.exceptions import InvalidEmail, SocialAuthBaseException
from social_core.pipeline.partial import partial
from social_django.middleware import SocialAuthExceptionMiddleware as OldSocialAuthExceptionMiddleware

from judge.forms import ProfileForm
from judge.models import Language, Profile

logger = logging.getLogger('judge.social_auth')


class GitHubSecureEmailOAuth2(GithubOAuth2):
    name = 'github-secure'

    def user_data(self, access_token, *args, **kwargs):
        data = self._user_data(access_token)
        try:
            emails = self._user_data(access_token, '/emails')
        except (HTTPError, ValueError, TypeError):
            emails = []

        emails = [(e.get('email'), e.get('primary'), 0) for e in emails if isinstance(e, dict) and e.get('verified')]
        emails.sort(key=itemgetter(1), reverse=True)
        emails = list(map(itemgetter(0), emails))

        if emails:
            data['email'] = emails[0]
        else:
            data['email'] = None

        return data


def slugify_username(username, renotword=re.compile(r'[^\w]')):
    return renotword.sub('', username.replace('-', '_'))


def verify_email(backend, details, *args, **kwargs):
    if not details['email']:
        raise InvalidEmail(backend)
    # Ràng buộc chỉ áp dụng khi người dùng đăng nhập bằng Google
    # Điều này giúp tránh xung đột với các phương thức khác như Github (nếu có)
    if backend.name == 'google-oauth2':
        # Regex kiểm tra định dạng stu<mã_sinh_viên>@hnue.edu.vn
        # Nếu mã sinh viên chỉ bao gồm số, sử dụng \d+
        # Nếu mã sinh viên có chứa cả chữ cái, hãy thay \d+ bằng [a-zA-Z0-9]+
        if not re.match(r'^stu\d+@hnue\.edu\.vn$', details['email']):
            raise InvalidEmail(backend)


class SocialPostAuthForm(forms.Form):
    username = forms.RegexField(regex=re.compile(r'^\w+$', re.ASCII), max_length=30, label='Username',
                                error_messages={'invalid': 'A username must contain letters, numbers, or underscores.'})
    password = forms.CharField(label='Password', strip=False, widget=forms.PasswordInput(),
                               help_text=password_validation.password_validators_help_text_html(),
                               validators=[password_validation.validate_password])
    password_confirm = forms.CharField(label='Retype password', widget=forms.PasswordInput(), strip=False)

    def clean_username(self):
        if User.objects.filter(username=self.cleaned_data['username']).exists():
            raise forms.ValidationError('Sorry, the username is taken.')
        return self.cleaned_data['username']

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('password')
        password_confirm = cleaned_data.get('password_confirm')
        if password and password_confirm and password != password_confirm:
            self.add_error('password_confirm', "Passwords didn't match")


@partial
def get_username_password(backend, user, username=None, *args, **kwargs):
    if not user:
        request = backend.strategy.request
        if request.POST:
            form = SocialPostAuthForm(request.POST)
            if form.is_valid():
                return {'username': form.cleaned_data['username'],
                        'password': form.cleaned_data['password']}
        else:
            form = SocialPostAuthForm(initial={'username': username})
        return render(request, 'registration/username_select.html', {
            'title': 'Set up your account', 'form': form,
        })


def add_password(user, password=None, *args, **kwargs):
    if password:
        user.set_password(password)
        user.save()


@partial
def make_profile(backend, user, response, is_new=False, *args, **kwargs):
    if is_new:
        if not hasattr(user, 'profile'):
            profile = Profile(user=user)
            profile.language = Language.get_default_language()
            logger.info('Info from %s: %s', backend.name, response)
            profile.save()
            form = ProfileForm(instance=profile, user=user)
        else:
            data = backend.strategy.request_data()
            logger.info(data)
            form = ProfileForm(data, instance=user.profile, user=user)
            if form.is_valid():
                with revisions.create_revision(atomic=True):
                    form.save()
                    revisions.set_user(user)
                    revisions.set_comment('Updated on registration')
                    return
        return render(backend.strategy.request, 'registration/profile_creation.html', {
            'title': 'Create your profile', 'form': form,
        })


class SocialAuthExceptionMiddleware(OldSocialAuthExceptionMiddleware):
    def process_exception(self, request, exception):
        if isinstance(exception, SocialAuthBaseException):
            # 1. Lấy thông báo lỗi mặc định từ thư viện
            message = self.get_message(request, exception)
            
            # 2. Ghi đè thông báo nếu ngoại lệ cụ thể là InvalidEmail
            if isinstance(exception, InvalidEmail):
                message = "Bạn chỉ có thể sử dụng email sinh viên HNUE định dạng stu<mã_sinh_viên>@hnue.edu.vn."
                
            # 3. Chuyển hướng kèm theo thông báo đã tùy chỉnh
            return HttpResponseRedirect('%s?message=%s' % (reverse('social_auth_error'),
                                                           quote(message)))